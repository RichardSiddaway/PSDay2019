ALL CODE IS SUPPLIED AS IS WITH NO WARRANTY OR GUARANTEE.
IT'S YOUR RESPONSIBILITY TO TEST IN YOUR ENVIRONMENT

See also

https://www.youtube.com/watch?v=Tz7A0vfZpRo

for a great example of using runspaces