﻿<#
  Using thread jobs
    separate thread per job

    Default is 5 jobs at one time - ThrottleLimit
#>
## clean any existing jobs
Get-Job | Remove-Job

$computers = Get-VM -Name W19* | Where-Object Name -ne 'W19ND01' | 
Sort-Object -Property Name |
Select-Object -ExpandProperty Name

foreach ($computer in $computers) {
  
  $sb = {
    $count = Invoke-Command -ScriptBlock {
      Get-WinEvent -FilterHashtable @{LogName='Application'; Id=2809} -ErrorAction SilentlyContinue  |
      Measure-Object 
    } -VMName $using:computer -Credential $using:cred

    $props = [ordered]@{
      Server = $count.PSComputerName
      ErrorCount = $count.Count
    }
    New-Object -TypeName PSObject -Property $props

    ## this is just for demo purposes
    Start-Sleep -Seconds 30
  }
  Start-ThreadJob -Name "JOB-$computer" -ScriptBlock $sb
}