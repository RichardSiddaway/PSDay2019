<#
    Viewing Jobs

    VIEW PROCESSES
#>
## manually run
# Get-Job

foreach ($computer in $computers) {
  Receive-Job -Name "JOB-$computer" -Keep |
  Select-Object Server, ErrorCount
}

## manually run
# Get-Job | Remove-Job