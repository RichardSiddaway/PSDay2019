﻿<#
 run in separate powershell session
#>

#Get-Process power*

while ($true) {Get-Process -Name 'powershell*', pwsh; ""; Start-Sleep -Seconds 2}