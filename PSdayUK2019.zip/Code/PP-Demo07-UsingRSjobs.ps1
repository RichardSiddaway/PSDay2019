﻿<#
  using runspaces via PoshRSjobs module
#>
## import module
##   'parallels job cmdlets'
<#
RUN MANUALLY 

Import-Module -Name PoshRSJob
Get-Command -Module PoshRSJob

#>

Get-Job | Remove-Job

$computers = Get-VM -Name W19* | Where-Object Name -ne 'W19ND01' | 
Sort-Object -Property Name |
Select-Object -ExpandProperty Name

<#
     DON'T use foreach - get runspace pool per iteration
     Notice use of {$_}
     use throttle (default 5) to set concurrent runspaces
     scriptblock parameter is pipeline input !!!
#>
$computers |
   Start-RSJob -Name {"JOB-$_"} -Throttle 3 -ScriptBlock {
     param ([string]$computer)
     $count = Invoke-Command -ScriptBlock {
      Get-WinEvent -FilterHashtable @{LogName='Application'; Id=2809} -ErrorAction SilentlyContinue  |
      Measure-Object 
    } -VMName $computer -Credential $using:cred

    $props = [ordered]@{
      Server = $count.PSComputerName
      ErrorCount = $count.Count
    }
    New-Object -TypeName PSObject -Property $props

    ## this is just for demo purposes
    Start-Sleep -Seconds 10
  }
<#
  notice only 3 running at a time
  HasMoreData always appears to be false 
#>
Get-RSJob

## 
## RUN MANUALLY
##

<#
  Receive-RSjob DOESN'T strip data
foreach ($computer in $computers) {
  Receive-RSjob -Name "JOB-$computer"   
}
#>

## clean up
##Get-RSJob | Remove-RSJob