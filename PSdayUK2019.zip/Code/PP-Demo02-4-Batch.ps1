<#
   manual batching 
     run each batch in separate powershell session
     very manual
     could have data in files
     need to modify batches as things change
     resources needed to run!
     collating results difficult
#>

$computers = Get-VM -Name W19* | Where-Object Name -ne 'W19ND01' | 
Sort-Object -Property Name |
Select-Object -ExpandProperty Name

Write-Information -MessageData "Batch 1"  -InformationAction Continue
Invoke-Command -ScriptBlock {
    Get-WinEvent -FilterHashtable @{LogName='Application'; Id=2809} -ErrorAction SilentlyContinue  |
    Measure-Object 
} -VMName $computers[0,1] -Credential $cred  |
Select-Object PSComputerName, Count

Write-Information -MessageData "`nBatch 2"  -InformationAction Continue
Invoke-Command -ScriptBlock {
    Get-WinEvent -FilterHashtable @{LogName='Application'; Id=2809} -ErrorAction SilentlyContinue  |
    Measure-Object 
} -VMName $computers[2,3] -Credential $cred  |
Select-Object PSComputerName, Count

Write-Information -MessageData "`nBatch 3"  -InformationAction Continue
Invoke-Command -ScriptBlock {
    Get-WinEvent -FilterHashtable @{LogName='Application'; Id=2809} -ErrorAction SilentlyContinue  |
    Measure-Object 
} -VMName $computers[4,5] -Credential $cred  |
Select-Object PSComputerName, Count
