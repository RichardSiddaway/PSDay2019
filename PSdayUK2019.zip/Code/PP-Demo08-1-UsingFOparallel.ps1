<#
  using foreach-object -parallel
    simple to code

    show new syntax manually
    Get-Command ForEach-Object -Syntax
#>

Get-VM -Name W19* | Where-Object Name -ne 'W19ND01' | 
Sort-Object -Property Name |
Select-Object -ExpandProperty Name |
ForEach-Object -Parallel {

    $count = Invoke-Command -ScriptBlock {
        Get-WinEvent -FilterHashtable @{LogName='Application'; Id=2809} -ErrorAction SilentlyContinue  |
        Measure-Object 
    } -VMName $psitem -Credential $using:cred

    $props = [ordered]@{
        Server = $count.PSComputerName
        ErrorCount = $count.Count
    }
    New-Object -TypeName PSObject -Property $props
}