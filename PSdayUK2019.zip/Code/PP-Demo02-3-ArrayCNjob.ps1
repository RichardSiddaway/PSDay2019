<#
  array of computers
  run as jobs
#>

$computers = Get-VM -Name W19* | Where-Object Name -ne 'W19ND01' | 
Sort-Object -Property Name |
Select-Object -ExpandProperty Name

Invoke-Command -ScriptBlock {
    Get-WinEvent -FilterHashtable @{LogName='Application'; Id=2809} -ErrorAction SilentlyContinue  |
    Measure-Object 
} -VMName $computers -Credential $cred -AsJob  

<#
Get-Job

Get-Job -IncludeChildJob

Get-Job -IncludeChildJob | Receive-Job -Keep

# view single job
Get-Job | Receive-Job -Keep | select -f 1 | fl *

# this is interesting
Get-Job -IncludeChildJob | Receive-Job -Keep | Select-Object PSComputerName, Count

# this is what we want
Get-Job | Receive-Job -Keep | Select-Object PSComputerName, Count
#>