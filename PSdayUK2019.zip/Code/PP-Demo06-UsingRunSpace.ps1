﻿<#
  using runspaces

  RUN THIS BY COPYING CODE TO CONSOLE FOR DEMO
  DON'T USE MORE THAN 3 RUNSPACESin DEMO AS ISSUE WITH 
  SOMETIMES NOT RETURNING SERVER NAME - RESOURCES?
#>

$computers = Get-VM -Name W19* | Where-Object Name -ne 'W19ND01' | 
Sort-Object -Property Name | 
Select-Object -ExpandProperty Name

$cred = Get-Credential -Credential manticore\richard

## create runspace pool with min =1 and max = 3 runspaces
$rp = [runspacefactory]::CreateRunspacePool(1,3)

## create powershell and link to runspace pool
$ps = [powershell]::Create()
$ps.RunspacePool = $rp

$rp.Open()

$cmds = New-Object -TypeName System.Collections.ArrayList

$computers | ForEach-Object {
  $psa = [powershell]::Create()
  $psa.RunspacePool = $rp

  [void]$psa.AddScript({
     param ($computer, $cred)
     
     $count = Invoke-Command -ScriptBlock {
      Get-WinEvent -FilterHashtable @{LogName='Application'; Id=2809} -ErrorAction SilentlyContinue  |
      Measure-Object 
     } -VMName $computer -Credential $cred

    $props = [ordered]@{
        Server = $count.PSComputerName
        ErrorCount = $count.Count
    }

    New-Object -TypeName PSObject -Property $props
   })

   [void]$psa.AddParameter('computer',"$psitem")
   [void]$psa.AddParameter('cred',$cred)
   $handle = $psa.BeginInvoke()

   $temp = '' | Select-Object PowerShell, Handle
   $temp.PowerShell = $psa
   $temp.Handle = $handle

   [void]$cmds.Add($temp)
}

## view progress
$cmds | Select-Object -ExpandProperty handle

## retreive data
$cmds | ForEach-Object {$_.PowerShell.EndInvoke($_.Handle)}

## clean up
$cmds | ForEach-Object {$_.PowerShell.Dispose()}  
$rp.Close()
$rp.Dispose() 