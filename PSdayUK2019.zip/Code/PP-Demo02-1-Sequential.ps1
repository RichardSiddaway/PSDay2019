<#
  using foreach
    simple to code
    sequential processing
    using Foreach-Object just as sequential
#>
##################################################
###   CREATE CREDENTIAL
###   BEFORE RUNNING ANYMORE DEMOS !!!
###
###   $cred = Get-Credential -Credential manticore\richard
###
##################################################

$computers = Get-VM -Name W19* | Where-Object Name -ne 'W19ND01' | 
Sort-Object -Property Name |
Select-Object -ExpandProperty Name

foreach ($computer in $computers) {

    $count = Invoke-Command -ScriptBlock {
        Get-WinEvent -FilterHashtable @{LogName='Application'; Id=2809} -ErrorAction SilentlyContinue  |
        Measure-Object 
    } -VMName $computer -Credential $cred

    $props = [ordered]@{
        Server = $count.PSComputerName
        ErrorCount = $count.Count
    }
    New-Object -TypeName PSObject -Property $props
}