﻿<#
   Starts just the VMs needed for demo
#>

$vms = @"
W19DC01
W19FS01
W19SC01
W19SC02
W19SC03
W19SC04
"@ -split "`n"

$i = 0
## start VMs
foreach ($vm in $vms){
    $comp = Get-VM -Name $vm.Trim()
    if ($comp.State -eq  'Off') {
        Start-VM -VM $comp -Verbose
        $i++
        if ($i -lt $vms.Count){
            Start-Sleep -Seconds 180
        }
        
    }
    else {
        Write-Warning -Message "$vm NOT in state to be started. Check current state"
    }
}